# Quitanda — modelo de estudo

Este pacote é apenas uma estrutura inicial para você completar e testar no VS Code.
A avaliação enviada informa que o uso de IA para produzir a entrega não é permitido.
Por isso, os arquivos de configuração abaixo são lembretes com tarefas, não uma solução pronta.

## Estrutura esperada

- `frontend/`: aplicação web e seu Dockerfile
- `backend/`: API Node.js e seu Dockerfile
- `backend/db/bkt_quitanda.sql`: script SQL fornecido pelo professor
- `docker-compose.yml`: orquestração dos serviços

## Antes de configurar

1. Coloque os arquivos originais do frontend dentro de `frontend/`.
2. Coloque os arquivos originais da API dentro de `backend/`.
3. Copie o arquivo `bkt_quitanda.sql` fornecido na atividade para `backend/db/`.
4. Abra os `package.json` e confira os comandos de inicialização e as portas usadas.
5. Complete os arquivos TODO com base no que você aprendeu em aula e na documentação Docker indicada na atividade.

## Comandos para validar seu trabalho

Execute na pasta raiz do projeto:

```bash
docker compose config
docker compose up --build
docker compose ps
```

Para encerrar:

```bash
docker compose down
```

Não apague o banco de dados nem volumes persistentes sem entender as consequências.
